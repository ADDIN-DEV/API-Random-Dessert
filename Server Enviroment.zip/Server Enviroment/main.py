from flask import Flask, jsonify, render_template
import random

app = Flask(__name__)

# Data dessert langsung dari Python
desserts = [
    {
        "name": "Chocolate Lava Cake",
        "description": "Soft chocolate cake with a melted center, served with vanilla ice cream.",
        "price": "25.000 IDR"
    },
    {
        "name": "Strawberry Cheesecake",
        "description": "Classic cheesecake topped with fresh strawberries and strawberry sauce.",
        "price": "30.000 IDR"
    },
    {
        "name": "Banana Split",
        "description": "Fresh banana served with scoops of vanilla, chocolate, and strawberry ice cream.",
        "price": "28.000 IDR"
    },
    {
        "name": "Matcha Pudding",
        "description": "Smooth Japanese matcha pudding topped with whipped cream.",
        "price": "22.000 IDR"
    },
    {
        "name": "Tiramisu enak",
        "description": "Italian dessert made of layers of coffee-soaked ladyfingers and mascarpone cream.",
        "price": "35.000 IDR"
    }
]

# API: Semua dessert
@app.route('/api/desserts', methods=['GET'])
def get_desserts():
    return jsonify({
        "date": "2025-03-12",
        "desserts": desserts
    })

# API: Random dessert
@app.route('/api/desserts/random', methods=['GET'])
def get_random_dessert():
    random_dessert = random.choice(desserts)
    return jsonify(random_dessert)

# Homepage (HTML)
@app.route('/')
def index():
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
